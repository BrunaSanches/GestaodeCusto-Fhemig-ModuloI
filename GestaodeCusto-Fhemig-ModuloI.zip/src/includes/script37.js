function expandirImagem(elemento) {
    elemento.parentElement.classList.toggle("expanded");
  }